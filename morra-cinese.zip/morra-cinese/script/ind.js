var buttonStart;
var scelta;
var foglia;
var forbice;
var sasso;
var persona;
var boxCpu   ;
var risultato = document.getElementById("risultato");
var risultatoPersona = document.getElementById("punteggioYou");
var risultatoCpu = document.getElementById("punteggioCpu");
var numeriCasuali;

buttonStart = document.getElementById("inizia");
scelta = document.getElementById("scelta");
persona = document.getElementById("you");
cpu = document.getElementById("cpu");
foglia = document.getElementById("foglia");
sasso = document.getElementById("sasso");
forbice = document.getElementById("forbice");


buttonStart.onclick = function(){
    buttonStart.style.opacity = 0;
    scelta.style.display = "block";}




foglia.onclick = function(){
    scelta.style.display = "none";
    buttonStart.style.opacity = 1 ;
    persona.style.backgroundImage = 'url("../immagini/foglia.png")';
    numeriCasuali = Math.floor(Math.random() * 3);
    


    if (numeriCasuali == 0){
        risultato.innerHTML = "pareggio";
        cpu.style.backgroundImage = 'url("../immagini/foglia.png")';
        risultato.style.display  = "block";
    } if(numeriCasuali == 1){
        risultato.innerHTML ="perdita";
        cpu.style.backgroundImage = 'url("../immagini/forbice.png")';
        risultato.style.display = "block";
        risultatoCpu.innerHTML = Number(risultatoCpu.innerHTML) + 1;
    }
    else{
        risultato.innerHTML = "vittoria";
        risultato.style.display = "block";
        cpu.style.backgroundImage = 'url("../immagini/sasso.png")';
        risultatoPersona.innerHTML = Number(risultatoPersona.innerHTML) + 1;

    }
   
    /*0 fpglia
      1 forbice
      2 sasso */


}

sasso.onclick = function(){
    scelta.style.display = "none";
    buttonStart.style.opacity = 1 ;
    persona.style.backgroundImage = 'url("../immagini/sasso9.png")';
    numeriCasuali = Math.floor(Math.random() * 3);
    


    if (numeriCasuali == 0){
        risultato.innerHTML = "perdita";
        cpu.style.backgroundImage = 'url("../immagini/foglia.png")';
        risultato.style.display  = "block";
        risultatoCpu.innerHTML = Number(risultatoCpu.innerHTML) + 1;

    } if(numeriCasuali == 1){
        risultato.innerHTML ="vittoria";
        cpu.style.backgroundImage = 'url("../immagini/forbice.png")';
        risultato.style.display = "block";
        risultatoPersona.innerHTML = Number(risultatoPersona.innerHTML) + 1;
    }
    else{
        risultato.innerHTML = "parità";
        risultato.style.display = "block";
        cpu.style.backgroundImage = 'url("../immagini/sasso.png")';
      
    }

}

forbice.onclick = function(){
    scelta.style.display = "none";
    buttonStart.style.opacity = 1 ;
    persona.style.backgroundImage = 'url("../immagini/forbice.png")';
    numeriCasuali = Math.floor(Math.random() * 3);
    


    if (numeriCasuali == 0){
        risultato.innerHTML = "vittoria";
        cpu.style.backgroundImage = 'url("../immagini/foglia.png")';
        risultato.style.display  = "block";
        risultatoPersona.innerHTML = Number(risultatoPersona.innerHTML) + 1;

    } if(numeriCasuali == 1){
        risultato.innerHTML ="pareggio";
        cpu.style.backgroundImage = 'url("../immagini/forbice.png")';
        risultato.style.display = "block";
        /*risultatoCpu.innerHTML = Number(risultatoPersona.innerHTML) +1;
    */}
    else{
        risultato.innerHTML = "perdita";
        risultato.style.display = "block";
        cpu.style.backgroundImage = 'url("../immagini/sasso.png")';
        risultatoCpu.innerHTML = Number(risultatoCpu.innerHTML) + 1;}



        //0 foglia 2sasso 1forbice
}